import React, { createContext, useContext, useReducer, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  Pressable,
  useWindowDimensions,
  ActivityIndicator,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
export const categories = ['Достопримечательности', 'Парки', 'Рестораны'];
export const places = [
  {
    id: '1',
    name: 'Мечеть имени Машхура Жусупа',
    category: 'Достопримечательности',
    description:
      'Один из самых величественных и красивых архитектурных объектов города, расположенный в центре парка. Здание мечети выполнено в форме восьмиконечной звезды, а его голубой купол высотой 54 метра и четыре 63-метровых минарета видны из многих точек Павлодара.',
    localImage: require('./mechet.jpg'),
    rating: 5.0,
  },
  {
    id: '2',
    name: 'Благовещенский кафедральный собор',
    category: 'Достопримечательности',
    description:
      'Главный православный храм Павлодара, построенный в классическом стиле с золотыми куполами и высокой колокольней. Собор окружен зелёным сквером и славится своим богатым внутренним убранством, резным иконостасом и изящной архитектурой.',
    localImage: require('./hram.jpg'),
    rating: 5.0,
  },
  {
    id: '3',
    name: 'Набережная г. Павлодар',
    category: 'Достопримечательности',
    description:
      'Одна из самых длинных и красивых набережных в Казахстане. Настоящая визитная карточка города с террасами, смотровыми площадками, уютными аллеями и ухоженными газонами. Набережная спускается к центральному пляжу, а вечером здесь зажигается красивая подсветка и работает светомузыкальный фонтан.',
    localImage: require('./nabka.jpg'),
    rating: 5.0,
  },
  {
    id: '4',
    name: 'Городской сад г.Павлодар',
    category: 'Парки',
    description:
      'Одно из самых популярных и старейших мест развлечения и семейного досуга в центре Павлодара. В парке оборудованы аттракционы для детей и взрослых, игровые зоны, работают детские кафе и палатки со сладостями.',
    localImage: require('./gorsad.jpg'),
    rating: 4.4,
  },
  {
    id: '5',
    name: 'Парк афганцев',
    category: 'Парки',
    description:
      'Сквер и мемориальный комплекс, расположенный в сквере по улице Лермонтова. Это тихое и памятное место города с ухоженными аллеями, тенистыми деревьями и памятником воинам-афганцам. Парк отлично подходит для спокойных прогулок и отдыха в центре города.',
    localImage: require('./afgan.jpg'),
    rating: 4.7,
  },
  {
    id: '6',
    name: 'Ресторан «Da Vinci»',
    category: 'Рестораны',
    description:
      'Стильный ресторан премиум-класса с авторской европейской, итальянской и паназиатской кухней. Заведение славится безупречной прожаркой стейков, изысканной подачей блюд, большим выбором коктейлей и современным уютным интерьером.',
    localImage: require('./vinci.jpg'),
    rating: 5,
  },
  {
    id: '7',
    name: 'Ресторан «Alpenhof»',
    category: 'Рестораны',
    description:
      'Атмосферный ресторан европейской и немецкой кухни в баварском стиле. Заведение известное своей собственной сыроварней, фирменными колбасками, сочными стейками и изысканной подачей блюд в колоритном интерьере.',
    localImage: require('./alpenhof.jfif'),
    rating: 4.7,
  },
];
const initialState = {
  places: places,
  categories: categories,
  selectedCategory: null,
  selectedPlace: null,
  isLoading: true,
};
const reducer = (state, action) => {
  switch (action.type) {
    case 'SET_INITIAL_DATA':
      return { ...state, places: action.payload, isLoading: false };
    case 'SELECT_CATEGORY':
      return { ...state, selectedCategory: action.payload };
    case 'SELECT_PLACE':
      return { ...state, selectedPlace: action.payload };
    case 'SAVE_PLACES':
      AsyncStorage.setItem('@places', JSON.stringify(state.places));
      return state;
    default:
      return state;
  }
};
const PlacesContext = createContext();

export const PlacesProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const loadData = async () => {
      try {
        const savedPlaces = await AsyncStorage.getItem('@places');
        if (savedPlaces !== null) {
          dispatch({
            type: 'SET_INITIAL_DATA',
            payload: JSON.parse(savedPlaces),
          });
        } else {
          dispatch({ type: 'SET_INITIAL_DATA', payload: places });
        }
      } catch (e) {
        dispatch({ type: 'SET_INITIAL_DATA', payload: places });
      }
    };
    loadData();
  }, []);
  return (
    <PlacesContext.Provider value={{ state, dispatch }}>
      {children}
    </PlacesContext.Provider>
  );
};
export const usePlaces = () => useContext(PlacesContext);
const getImageSource = (place) => {
  if (place.localImage) {
    return place.localImage;
  }
  if (place.imageUrl) {
    return { uri: place.imageUrl };
  }
  return { uri: 'https://via.placeholder.com/150' };
};
const CategoryCard = ({ title, onPress }) => (
  <Pressable style={styles.categoryCard} onPress={onPress}>
    <Text style={styles.categoryTitle}>{title}</Text>
  </Pressable>
);
const PlaceItem = ({ place, onPress }) => {
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  const imageSize = isTablet ? 140 : 90;
  return (
    <Pressable style={styles.placeCard} onPress={onPress}>
      <Image
        source={getImageSource(place)}
        style={{
          width: imageSize,
          height: imageSize,
          borderRadius: 8,
        }}
        resizeMode="cover"
      />
      <View style={{ flex: 1, marginLeft: 16 }}>
        <Text style={styles.placeName}>{place.name}</Text>
        <Text style={styles.placeRating}>⭐ {place.rating}</Text>
        <Text style={styles.placeShortDesc} numberOfLines={2}>
          {place.description}
        </Text>
      </View>
    </Pressable>
  );
};
function CategoriesScreen({ navigation }) {
  const { state, dispatch } = usePlaces();

  if (state.isLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#0D6EFD" />
      </View>
    );
  }
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.sectionHeader}>Выберите категорию</Text>
      {state.categories.map((category) => (
        <CategoryCard
          key={category}
          title={category}
          onPress={() => {
            dispatch({ type: 'SELECT_CATEGORY', payload: category });
            navigation.navigate('Places', { category });
          }}
        />
      ))}
    </ScrollView>
  );
}
function PlacesScreen({ route, navigation }) {
  const { category } = route.params;
  const { state, dispatch } = usePlaces();
  const placesInCategory = state.places.filter(
    (place) => place.category === category
  );
  return (
    <ScrollView style={styles.screenBg}>
      {placesInCategory.map((place) => (
        <PlaceItem
          key={place.id}
          place={place}
          onPress={() => {
            dispatch({ type: 'SELECT_PLACE', payload: place });
            navigation.navigate('PlaceDetail', { id: place.id });
          }}
        />
      ))}
    </ScrollView>
  );
}
function PlaceDetailScreen({ route }) {
  const { id } = route.params;
  const { state } = usePlaces();
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  const place = state.places.find((p) => p.id === id);
  if (!place) {
    return (
      <View style={styles.centered}>
        <Text>Место не найдено</Text>
      </View>
    );
  }
  return (
    <ScrollView style={styles.screenBg} contentContainerStyle={{ padding: 16 }}>
      <Image
        source={getImageSource(place)}
        style={[styles.detailImage, { height: isTablet ? 350 : 220 }]}
        resizeMode="cover"
      />
      <View style={styles.detailCard}>
        <View style={styles.detailHeader}>
          <Text style={styles.detailTitle}>{place.name}</Text>
          <Text style={styles.detailRating}>⭐ {place.rating}</Text>
        </View>
        <Text style={styles.categoryBadge}>{place.category}</Text>
        <Text style={styles.detailDescription}>{place.description}</Text>
      </View>
    </ScrollView>
  );
}
const Stack = createNativeStackNavigator();
export default function App() {
  return (
    <PlacesProvider>
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: '#0D6EFD' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}>
          <Stack.Screen
            name="Categories"
            component={CategoriesScreen}
            options={{ title: 'Павлодар: Путеводитель' }}
          />
          <Stack.Screen
            name="Places"
            component={PlacesScreen}
            options={({ route }) => ({ title: route.params.category })}
          />
          <Stack.Screen
            name="PlaceDetail"
            component={PlaceDetailScreen}
            options={{ title: 'Детали места' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </PlacesProvider>
  );
}
const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  screenBg: {
    flex: 1,
    backgroundColor: '#F4F6F8',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#1A1D20',
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    padding: 24,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    borderLeftWidth: 5,
    borderLeftColor: '#0D6EFD',
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#212529',
  },
  placeCard: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginTop: 12,
    padding: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    alignItems: 'center',
  },
  placeName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1D20',
  },
  placeRating: {
    fontSize: 13,
    color: '#D97706',
    marginVertical: 4,
  },
  placeShortDesc: {
    fontSize: 13,
    color: '#6C757D',
  },
  detailImage: {
    width: '100%',
    borderRadius: 12,
    marginBottom: 16,
  },
  detailCard: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 12,
  },
  detailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1A1D20',
    flex: 1,
  },
  detailRating: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#D97706',
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#E7F5FF',
    color: '#0D6EFD',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 6,
    marginVertical: 10,
    fontSize: 12,
    fontWeight: '600',
  },
  detailDescription: {
    fontSize: 15,
    lineHeight: 22,
    color: '#495057',
    marginTop: 8,
  },
});