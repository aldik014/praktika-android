import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TextInput,
  TouchableOpacity,
  Modal,
  Alert,
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  StatusBar,
} from 'react-native';
import * as SQLite from 'expo-sqlite';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const db = SQLite.openDatabaseSync('movies.db');
const initDatabase = () => {
  try {
    db.execSync('PRAGMA foreign_keys = ON;');
    db.execSync(`
      CREATE TABLE IF NOT EXISTS genres (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
      );
    `);
    db.execSync(`
      CREATE TABLE IF NOT EXISTS movies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        genre_id INTEGER,
        director TEXT,
        year INTEGER,
        rating REAL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (genre_id) REFERENCES genres (id) ON DELETE SET NULL
      );
    `);
    const genreCount = db.getFirstSync('SELECT COUNT(*) as count FROM genres;');
    if (genreCount.count === 0) {
      db.execSync(`
        INSERT INTO genres (name) VALUES ('Фантастика'), ('Драма'), ('Экшен'), ('Комедия');
      `);
      db.execSync(`
        INSERT INTO movies (title, description, genre_id, director, year, rating) 
        VALUES (
          'Интерстеллар', 
          'Наше время на Земле подходит к концу, команда исследователей берет на себя самую важную миссию в истории человечества.', 
          1, 
          'Кристофер Нолан', 
          2014, 
          8.7
        );
      `);
    }
  } catch (error) {
    console.error('Ошибка инициализации БД:', error);
  }
};
initDatabase();
function HomeScreen({ navigation }) {
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedGenreId, setSelectedGenreId] = useState(null);
  const [loading, setLoading] = useState(true);
  const loadGenres = useCallback(() => {
    try {
      const results = db.getAllSync('SELECT * FROM genres ORDER BY name ASC;');
      setGenres(results);
    } catch (e) {
      console.error(e);
    }
  }, []);
  const loadMovies = useCallback(() => {
    try {
      setLoading(true);
      let query = `
        SELECT movies.*, genres.name as genre_name 
        FROM movies 
        LEFT JOIN genres ON movies.genre_id = genres.id
        WHERE 1=1
      `;
      const params = [];
      if (search.trim()) {
        query += ` AND movies.title LIKE ?`;
        params.push(`%${search.trim()}%`);
      }
      if (selectedGenreId) {
        query += ` AND movies.genre_id = ?`;
        params.push(selectedGenreId);
      }
      query += ` ORDER BY movies.id DESC;`;
      const results = db.getAllSync(query, params);
      setMovies(results);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [search, selectedGenreId]);
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadGenres();
      loadMovies();
    });
    return unsubscribe;
  }, [navigation, loadGenres, loadMovies]);
  useEffect(() => {
    loadMovies();
  }, [search, selectedGenreId, loadMovies]);
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Поиск фильма по названию..."
          placeholderTextColor="#8e8eab"
          value={search}
          onChangeText={setSearch}
        />
      </View>
      <View style={styles.filterContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity
            style={[
              styles.chip,
              selectedGenreId === null && styles.chipSelected,
            ]}
            onPress={() => setSelectedGenreId(null)}
          >
            <Text
              style={[
                styles.chipText,
                selectedGenreId === null && styles.chipTextSelected,
              ]}
            >
              Все жанры
            </Text>
          </TouchableOpacity>
          {genres.map((g) => (
            <TouchableOpacity
              key={g.id}
              style={[
                styles.chip,
                selectedGenreId === g.id && styles.chipSelected,
              ]}
              onPress={() => setSelectedGenreId(g.id)}
            >
              <Text
                style={[
                  styles.chipText,
                  selectedGenreId === g.id && styles.chipTextSelected,
                ]}
              >
                {g.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <View style={styles.topActions}>
        <TouchableOpacity
          style={styles.primaryBtn}
          onPress={() => navigation.navigate('MovieForm', { movie: null })}
        >
          <Text style={styles.btnText}>+ Добавить фильм</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.secondaryBtn}
          onPress={() => navigation.navigate('Genres')}
        >
          <Text style={styles.secondaryBtnText}>Жанры</Text>
        </TouchableOpacity>
      </View>
      {loading ? (
        <ActivityIndicator size="large" color="#00ff97" style={{ marginTop: 20 }} />
      ) : (
        <FlatList
          data={movies}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{ padding: 16 }}
          ListEmptyComponent={
            <Text style={styles.emptyText}>Фильмы не найдены</Text>
          }
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.movieCard}
              onPress={() => navigation.navigate('MovieDetail', { movieId: item.id })}
            >
              <View style={styles.cardHeader}>
                <Text style={styles.movieTitle}>{item.title}</Text>
                <Text style={styles.movieRating}>⭐ {item.rating || 'N/A'}</Text>
              </View>
              <Text style={styles.movieMeta}>
                {item.year ? `${item.year} г. • ` : ''}
                {item.genre_name || 'Без жанра'}
              </Text>
              {item.director ? (
                <Text style={styles.movieDirector}>Режиссер: {item.director}</Text>
              ) : null}
            </TouchableOpacity>
          )}
        />
      )}
    </SafeAreaView>
  );
}
function MovieDetailScreen({ route, navigation }) {
  const { movieId } = route.params;
  const [movie, setMovie] = useState(null);

  const loadMovieDetail = useCallback(() => {
    try {
      const res = db.getFirstSync(
        `SELECT movies.*, genres.name as genre_name 
         FROM movies 
         LEFT JOIN genres ON movies.genre_id = genres.id 
         WHERE movies.id = ?;`,
        [movieId]
      );
      setMovie(res);
    } catch (e) {
      console.error(e);
    }
  }, [movieId]);
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', loadMovieDetail);
    return unsubscribe;
  }, [navigation, loadMovieDetail]);
  const handleDelete = () => {
    Alert.alert('Удаление', 'Вы действительно хотите удалить этот фильм?', [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () => {
          db.runSync('DELETE FROM movies WHERE id = ?;', [movieId]);
          navigation.goBack();
        },
      },
    ]);
  };
  if (!movie) return <ActivityIndicator size="large" color="#00ff97" style={{ marginTop: 40 }} />;
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.detailBox}>
        <View style={styles.cardHeader}>
          <Text style={styles.detailTitle}>{movie.title}</Text>
          <Text style={styles.detailRating}>⭐ {movie.rating || 'N/A'}</Text>
        </View>
        <View style={styles.badgeRow}>
          <Text style={styles.badge}>{movie.genre_name || 'Без жанра'}</Text>
          {movie.year && <Text style={styles.badge}>{movie.year} год</Text>}
        </View>
        {movie.director && (
          <Text style={styles.detailDirector}>Режиссер: {movie.director}</Text>
        )}
        <Text style={styles.detailDescHeader}>Описание:</Text>
        <Text style={styles.detailDesc}>
          {movie.description || 'Описание отсутствует.'}
        </Text>
        <Text style={styles.dateText}>Запись создана: {movie.created_at}</Text>
      </View>
      <View style={styles.actionRow}>
        <TouchableOpacity
          style={[styles.primaryBtn, { flex: 1, marginRight: 8 }]}
          onPress={() => navigation.navigate('MovieForm', { movie })}
        >
          <Text style={styles.btnText}>Редактировать</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.deleteBtn, { flex: 1, marginLeft: 8 }]}
          onPress={handleDelete}
        >
          <Text style={styles.btnText}>Удалить</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}
function MovieFormScreen({ route, navigation }) {
  const existingMovie = route.params?.movie;
  const [title, setTitle] = useState(existingMovie?.title || '');
  const [description, setDescription] = useState(existingMovie?.description || '');
  const [director, setDirector] = useState(existingMovie?.director || '');
  const [year, setYear] = useState(existingMovie?.year ? String(existingMovie.year) : '');
  const [rating, setRating] = useState(existingMovie?.rating ? String(existingMovie.rating) : '');
  const [genreId, setGenreId] = useState(existingMovie?.genre_id || null);
  const [genres, setGenres] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  useEffect(() => {
    const list = db.getAllSync('SELECT * FROM genres ORDER BY name ASC;');
    setGenres(list);
    if (!genreId && list.length > 0) {
      setGenreId(list[0].id);
    }
  }, []);
  const handleSave = () => {
    if (!title.trim()) {
      Alert.alert('Ошибка', 'Введите название фильма');
      return;
    }
    const yearNum = year ? parseInt(year, 10) : null;
    const ratingNum = rating ? parseFloat(rating) : null;
    if (existingMovie) {
      db.runSync(
        `UPDATE movies 
         SET title=?, description=?, genre_id=?, director=?, year=?, rating=? 
         WHERE id=?;`,
        [title, description, genreId, director, yearNum, ratingNum, existingMovie.id]
      );
    } else {
      db.runSync(
        `INSERT INTO movies (title, description, genre_id, director, year, rating) 
         VALUES (?, ?, ?, ?, ?, ?);`,
        [title, description, genreId, director, yearNum, ratingNum]
      );
    }
    navigation.goBack();
  };
  const selectedGenreObj = genres.find((g) => g.id === genreId);
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.label}>Название фильма *</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="Например: Матрица"
        placeholderTextColor="#8e8eab"
      />
      <Text style={styles.label}>Жанр (Категория)</Text>
      <TouchableOpacity
        style={styles.selectBtn}
        onPress={() => setModalVisible(true)}
      >
        <Text style={styles.selectBtnText}>
          {selectedGenreObj ? selectedGenreObj.name : 'Выберите жанр'}
        </Text>
      </TouchableOpacity>
      <Text style={styles.label}>Режиссер</Text>
      <TextInput
        style={styles.input}
        value={director}
        onChangeText={setDirector}
        placeholder="Например: Братья Вачовски"
        placeholderTextColor="#8e8eab"
      />
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Год выпуска</Text>
          <TextInput
            style={styles.input}
            value={year}
            onChangeText={setYear}
            keyboardType="numeric"
            placeholder="1999"
            placeholderTextColor="#8e8eab"
          />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.label}>Рейтинг IMDb</Text>
          <TextInput
            style={styles.input}
            value={rating}
            onChangeText={setRating}
            keyboardType="decimal-pad"
            placeholder="8.7"
            placeholderTextColor="#8e8eab"
          />
        </View>
      </View>
      <Text style={styles.label}>Описание</Text>
      <TextInput
        style={[styles.input, { height: 90, textAlignVertical: 'top' }]}
        value={description}
        onChangeText={setDescription}
        multiline
        placeholder="Краткое содержание..."
        placeholderTextColor="#8e8eab"
      />
      <TouchableOpacity style={[styles.primaryBtn, { marginTop: 16 }]} onPress={handleSave}>
        <Text style={styles.btnText}>Сохранить</Text>
      </TouchableOpacity>
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Выберите жанр</Text>
            {genres.map((g) => (
              <TouchableOpacity
                key={g.id}
                style={styles.modalItem}
                onPress={() => {
                  setGenreId(g.id);
                  setModalVisible(false);
                }}
              >
                <Text style={styles.modalItemText}>{g.name}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={[styles.deleteBtn, { marginTop: 12 }]}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.btnText}>Закрыть</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}
function GenresScreen() {
  const [genres, setGenres] = useState([]);
  const [newGenre, setNewGenre] = useState('');

  const loadGenres = () => {
    const res = db.getAllSync('SELECT * FROM genres ORDER BY name ASC;');
    setGenres(res);
  };
  useEffect(() => {
    loadGenres();
  }, []);
  const handleAddGenre = () => {
    if (!newGenre.trim()) return;
    try {
      db.runSync('INSERT INTO genres (name) VALUES (?);', [newGenre.trim()]);
      setNewGenre('');
      loadGenres();
    } catch (e) {
      Alert.alert('Ошибка', 'Такой жанр уже существует');
    }
  };
  const handleDeleteGenre = (id) => {
    Alert.alert('Удаление', 'Удалить этот жанр? (У фильмов этот жанр сбросится)', [
      { text: 'Отмена', style: 'cancel' },
      {
        text: 'Удалить',
        style: 'destructive',
        onPress: () => {
          db.runSync('DELETE FROM genres WHERE id = ?;', [id]);
          loadGenres();
        },
      },
    ]);
  };
  return (
    <SafeAreaView style={styles.container}>
      <View style={{ padding: 16 }}>
        <Text style={styles.label}>Добавить новый жанр</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <TextInput
            style={[styles.input, { flex: 1, marginBottom: 0 }]}
            value={newGenre}
            onChangeText={setNewGenre}
            placeholder="Например: Ужасы"
            placeholderTextColor="#8e8eab"
          />
          <TouchableOpacity style={styles.primaryBtn} onPress={handleAddGenre}>
            <Text style={styles.btnText}>Добавить</Text>
          </TouchableOpacity>
        </View>
      </View>
      <FlatList
        data={genres}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }) => (
          <View style={styles.genreRow}>
            <Text style={styles.genreRowText}>{item.name}</Text>
            <TouchableOpacity onPress={() => handleDeleteGenre(item.id)}>
              <Text style={{ color: '#ff4d4d', fontWeight: 'bold' }}>Удалить</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </SafeAreaView>
  );
}
const Stack = createNativeStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="light-content" backgroundColor="#1b1b2f" />
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#1b1b2f' },
          headerTintColor: '#00ff97',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Фильмотека (SQLite CRUD)' }}
        />
        <Stack.Screen
          name="MovieDetail"
          component={MovieDetailScreen}
          options={{ title: 'О фильме' }}
        />
        <Stack.Screen
          name="MovieForm"
          component={MovieFormScreen}
          options={({ route }) => ({
            title: route.params?.movie ? 'Редактировать' : 'Новый фильм',
          })}
        />
        <Stack.Screen
          name="Genres"
          component={GenresScreen}
          options={{ title: 'Управление жанрами' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#12121e',
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  searchInput: {
    backgroundColor: '#1f1f33',
    color: '#ffffff',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#383858',
  },
  filterContainer: {
    paddingVertical: 10,
    paddingLeft: 16,
  },
  chip: {
    backgroundColor: '#1f1f33',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#383858',
  },
  chipSelected: {
    backgroundColor: '#00ff97',
    borderColor: '#00ff97',
  },
  chipText: {
    color: '#a0a0c0',
    fontSize: 13,
  },
  chipTextSelected: {
    color: '#12121e',
    fontWeight: 'bold',
  },
  topActions: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 8,
    marginBottom: 8,
  },
  primaryBtn: {
    backgroundColor: '#00ff97',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryBtn: {
    backgroundColor: '#2a2a44',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#3f3f66',
  },
  deleteBtn: {
    backgroundColor: '#ff4d4d',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnText: {
    color: '#12121e',
    fontWeight: 'bold',
  },
  secondaryBtnText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  movieCard: {
    backgroundColor: '#1f1f33',
    borderRadius: 10,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#383858',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  movieTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
  },
  movieRating: {
    color: '#00ff97',
    fontWeight: 'bold',
  },
  movieMeta: {
    color: '#8e8eab',
    fontSize: 13,
    marginTop: 4,
  },
  movieDirector: {
    color: '#a0a0c0',
    fontSize: 12,
    marginTop: 2,
  },
  emptyText: {
    color: '#8e8eab',
    textAlign: 'center',
    marginTop: 30,
  },
  detailBox: {
    backgroundColor: '#1f1f33',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#383858',
  },
  detailTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#00ff97',
    flex: 1,
  },
  detailRating: {
    fontSize: 18,
    color: '#00ff97',
    fontWeight: 'bold',
  },
  badgeRow: {
    flexDirection: 'row',
    gap: 8,
    marginVertical: 10,
  },
  badge: {
    backgroundColor: '#2a2a44',
    color: '#ffffff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontSize: 12,
  },
  detailDirector: {
    color: '#ffffff',
    fontSize: 14,
    marginBottom: 10,
  },
  detailDescHeader: {
    color: '#8e8eab',
    fontWeight: 'bold',
    marginTop: 10,
  },
  detailDesc: {
    color: '#e0e0ff',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 4,
  },
  dateText: {
    color: '#8e8eab',
    fontSize: 11,
    marginTop: 16,
  },
  actionRow: {
    flexDirection: 'row',
    marginTop: 16,
  },
  label: {
    color: '#8e8eab',
    marginBottom: 4,
    marginTop: 10,
    fontSize: 13,
  },
  input: {
    backgroundColor: '#1f1f33',
    color: '#ffffff',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#383858',
  },
  selectBtn: {
    backgroundColor: '#1f1f33',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#383858',
  },
  selectBtnText: {
    color: '#ffffff',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#1f1f33',
    borderRadius: 12,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00ff97',
    marginBottom: 12,
  },
  modalItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#383858',
  },
  modalItemText: {
    color: '#ffffff',
    fontSize: 16,
  },
  genreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1f1f33',
    padding: 14,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#383858',
  },
  genreRowText: {
    color: '#ffffff',
    fontSize: 15,
  },
});