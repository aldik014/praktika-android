import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>
      <Image
  source={require('./avatar.jfif')}
  style={styles.avatar}
    />
        />
        <Text style={styles.name}>Советкалиев Алдияр</Text>
        <Text style={styles.group}>Группа: АЖ-301(к)</Text>
        <View style={styles.divider} />
        <View style={styles.infoSection}>
          <Text style={styles.label}>Email:</Text>
          <Text style={styles.value}>sovetkaliev.2005@gmail.com</Text>
        </View>
        <View style={styles.nomerSection}>
          <Text style={styles.label}>Номер:</Text>
          <Text style={styles.value}>8-777-049-51-40</Text>
        </View>
        <View style={styles.infoSection}>
          <Text style={styles.label}>О себе / Хобби:</Text>
          <Text style={styles.value}>
            Увлекаюсь автоспортом.
          </Text>
        </View>
        <View style={styles.quoteBox}>
          <Text style={styles.quoteText}>
            «Нет ничего невозможного»
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#e9ecef',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 360,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212529',
    marginBottom: 4,
  },
  group: {
    fontSize: 16,
    color: '#6c757d',
    marginBottom: 16,
  },
  divider: {
    height: 1,
    width: '100%',
    backgroundColor: '#dee2e6',
    marginVertical: 12,
  },
  infoSection: {
    width: '100%',
    marginBottom: 12,
  },
  nomerSection: {
    width: '100%',
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    marginBottom: 2,
  },
  value: {
    fontSize: 15,
    color: '#212529',
    lineHeight: 20,
  },
  quoteBox: {
    marginTop: 12,
    padding: 12,
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#0d6efd',
    width: '100%',
  },
  quoteText: {
    fontStyle: 'italic',
    color: '#495057',
    fontSize: 13,
  },
});