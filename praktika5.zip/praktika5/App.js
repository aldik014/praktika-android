import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
  useWindowDimensions,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
const BASE_URL = 'https://rickandmortyapi.com/api';
const fetchData = async (endpoint, page = 1) => {
  const response = await fetch(`${BASE_URL}/${endpoint}?page=${page}`);
  if (!response.ok) {
    throw new Error(`Ошибка загрузки ${endpoint}: ${response.status}`);
  }
  return await response.json();
};
const InfoRow = ({ label, value }) => (
  <View style={styles.infoRow}>
    <Text style={styles.infoLabel}>{label}:</Text>
    <Text style={styles.infoValue} numberOfLines={1}>
      {value || 'unknown'}
    </Text>
  </View>
);
const LoadingErrorState = ({ loading, error, onRetry }) => {
  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#00ff97" />
        <Text style={{ color: '#fff', marginTop: 10 }}>Загрузка...</Text>
      </View>
    );
  }
  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Ошибка: {error}</Text>
        {onRetry && (
          <TouchableOpacity style={styles.retryButton} onPress={onRetry}>
            <Text style={styles.retryText}>Повторить</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  }
  return null;
};
function CharactersListScreen({ navigation }) {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState('');
  const { width } = useWindowDimensions();
  const numColumns = width >= 768 ? 3 : width >= 500 ? 2 : 1;
  const loadCharacters = useCallback(async (pageNum) => {
    try {
      if (pageNum === 1) setLoading(true);
      else setLoadingMore(true);
      const result = await fetchData('character', pageNum);
      setData((prev) => (pageNum === 1 ? result.results : [...prev, ...result.results]));
      setHasMore(!!result.info.next);
      setError('');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, []);
  useEffect(() => {
    loadCharacters(1);
  }, [loadCharacters]);
  const handleLoadMore = () => {
    if (!loadingMore && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      loadCharacters(nextPage);
    }
  };
  const renderCharacterCard = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, numColumns > 1 && { flex: 1, margin: 6 }]}
      onPress={() => navigation.navigate('CharacterDetails', { item })}
      activeOpacity={0.8}
    >
      <Image
        source={{ uri: item.image }}
        style={styles.cardImage}
        resizeMode="cover"
      />
      <View style={styles.cardBody}>
        <InfoRow label="Name" value={item.name} />
        <InfoRow label="Status" value={item.status} />
        <InfoRow label="Species" value={item.species} />
        <InfoRow label="Origin" value={item.origin?.name} />
        <InfoRow label="Location" value={item.location?.name} />
      </View>
    </TouchableOpacity>
  );
  if (loading) return <LoadingErrorState loading={true} />;
  if (error) return <LoadingErrorState error={error} onRetry={() => loadCharacters(1)} />;
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        key={numColumns}
        data={data}
        renderItem={renderCharacterCard}
        keyExtractor={(item) => item.id.toString()}
        numColumns={numColumns}
        contentContainerStyle={styles.listContainer}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListFooterComponent={
          loadingMore ? <ActivityIndicator size="small" color="#00ff97" style={{ margin: 16 }} /> : null
        }
      />
    </SafeAreaView>
  );
}
function LocationsListScreen({ navigation }) {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState('');
  const loadLocations = useCallback(async (pageNum) => {
    try {
      if (pageNum === 1) setLoading(true);
      else setLoadingMore(true);
      const result = await fetchData('location', pageNum);
      setData((prev) => (pageNum === 1 ? result.results : [...prev, ...result.results]));
      setHasMore(!!result.info.next);
      setError('');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, []);
  useEffect(() => {
    loadLocations(1);
  }, [loadLocations]);
  const handleLoadMore = () => {
    if (!loadingMore && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      loadLocations(nextPage);
    }
  };
  const renderLocationItem = ({ item }) => (
    <TouchableOpacity
      style={styles.textCard}
      onPress={() => navigation.navigate('LocationDetails', { item })}
      activeOpacity={0.8}
    >
      <Text style={styles.itemTitle}>{item.name}</Text>
      <View style={styles.badgeRow}>
        <Text style={styles.badge}>Тип: {item.type}</Text>
        <Text style={styles.badge}>Измерение: {item.dimension}</Text>
      </View>
      <Text style={styles.subText}>Резидентов: {item.residents.length}</Text>
    </TouchableOpacity>
  );
  if (loading) return <LoadingErrorState loading={true} />;
  if (error) return <LoadingErrorState error={error} onRetry={() => loadLocations(1)} />;
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderLocationItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListFooterComponent={
          loadingMore ? <ActivityIndicator size="small" color="#00ff97" style={{ margin: 16 }} /> : null
        }
      />
    </SafeAreaView>
  );
}
function EpisodesListScreen({ navigation }) {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState('');
  const loadEpisodes = useCallback(async (pageNum) => {
    try {
      if (pageNum === 1) setLoading(true);
      else setLoadingMore(true);
      const result = await fetchData('episode', pageNum);
      setData((prev) => (pageNum === 1 ? result.results : [...prev, ...result.results]));
      setHasMore(!!result.info.next);
      setError('');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, []);
  useEffect(() => {
    loadEpisodes(1);
  }, [loadEpisodes]);
  const handleLoadMore = () => {
    if (!loadingMore && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      loadEpisodes(nextPage);
    }
  };
  const renderEpisodeItem = ({ item }) => (
    <TouchableOpacity
      style={styles.textCard}
      onPress={() => navigation.navigate('EpisodeDetails', { item })}
      activeOpacity={0.8}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={styles.itemTitle}>{item.name}</Text>
        <Text style={styles.codeBadge}>{item.episode}</Text>
      </View>
      <Text style={styles.subText}>Дата выхода: {item.air_date}</Text>
      <Text style={styles.subText}>Персонажей: {item.characters.length}</Text>
    </TouchableOpacity>
  );
  if (loading) return <LoadingErrorState loading={true} />;
  if (error) return <LoadingErrorState error={error} onRetry={() => loadEpisodes(1)} />;
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderEpisodeItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListFooterComponent={
          loadingMore ? <ActivityIndicator size="small" color="#00ff97" style={{ margin: 16 }} /> : null
        }
      />
    </SafeAreaView>
  );
}
function DetailsScreen({ route }) {
  const { item } = route.params;
  if (item.image) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.detailCard}>
          <Image source={{ uri: item.image }} style={styles.detailImage} />
          <Text style={styles.detailTitle}>{item.name}</Text>

          <View style={styles.detailInfoBox}>
            <InfoRow label="Статус" value={item.status} />
            <InfoRow label="Раса" value={item.species} />
            <InfoRow label="Пол" value={item.gender} />
            <InfoRow label="Происхождение" value={item.origin?.name} />
            <InfoRow label="Локация" value={item.location?.name} />
            <InfoRow label="Эпизодов" value={item.episode?.length.toString()} />
          </View>
        </View>
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.detailCard}>
        <Text style={styles.detailTitle}>{item.name}</Text>
        <View style={styles.detailInfoBox}>
          {item.type && <InfoRow label="Тип" value={item.type} />}
          {item.dimension && <InfoRow label="Измерение" value={item.dimension} />}
          {item.episode && <InfoRow label="Код эпизода" value={item.episode} />}
          {item.air_date && <InfoRow label="Дата выхода" value={item.air_date} />}
          {item.residents && <InfoRow label="Резидентов" value={item.residents.length.toString()} />}
          {item.characters && <InfoRow label="Персонажей" value={item.characters.length.toString()} />}
          <InfoRow label="Дата создания" value={new Date(item.created).toLocaleDateString()} />
        </View>
      </View>
    </SafeAreaView>
  );
}
const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const commonHeaderOptions = {
  headerStyle: { backgroundColor: '#1b1b2f' },
  headerTintColor: '#00ff97',
  headerTitleStyle: { fontWeight: 'bold' },
};
function CharactersStack() {
  return (
    <Stack.Navigator screenOptions={commonHeaderOptions}>
      <Stack.Screen name="CharactersList" component={CharactersListScreen} options={{ title: 'Персонажи' }} />
      <Stack.Screen name="CharacterDetails" component={DetailsScreen} options={{ title: 'Детали персонажа' }} />
    </Stack.Navigator>
  );
}
function LocationsStack() {
  return (
    <Stack.Navigator screenOptions={commonHeaderOptions}>
      <Stack.Screen name="LocationsList" component={LocationsListScreen} options={{ title: 'Локации' }} />
      <Stack.Screen name="LocationDetails" component={DetailsScreen} options={{ title: 'Детали локации' }} />
    </Stack.Navigator>
  );
}
function EpisodesStack() {
  return (
    <Stack.Navigator screenOptions={commonHeaderOptions}>
      <Stack.Screen name="EpisodesList" component={EpisodesListScreen} options={{ title: 'Эпизоды' }} />
      <Stack.Screen name="EpisodeDetails" component={DetailsScreen} options={{ title: 'Детали эпизода' }} />
    </Stack.Navigator>
  );
}
export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="light-content" backgroundColor="#1b1b2f" />
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarStyle: { backgroundColor: '#1b1b2f', borderTopColor: '#2d2d44' },
          tabBarActiveTintColor: '#00ff97',
          tabBarInactiveTintColor: '#8e8eab',
          tabBarLabelStyle: { fontSize: 13, fontWeight: 'bold', paddingBottom: 4 },
        }}
      >
        <Tab.Screen name="Characters" component={CharactersStack} options={{ title: 'Персонажи' }} />
        <Tab.Screen name="Locations" component={LocationsStack} options={{ title: 'Локации' }} />
        <Tab.Screen name="Episodes" component={EpisodesStack} options={{ title: 'Эпизоды' }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#12121e',
  },
  listContainer: {
    padding: 12,
  },
  center: {
    flex: 1,
    backgroundColor: '#12121e',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#ff4d4d',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#00ff97',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryText: {
    color: '#12121e',
    fontWeight: 'bold',
  },
  card: {
    backgroundColor: '#1f1f33',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#383858',
    marginBottom: 16,
    overflow: 'hidden',
    elevation: 4,
  },
  cardImage: {
    width: '100%',
    height: 180,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  cardBody: {
    padding: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2a2a44',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: '#3f3f66',
  },
  infoLabel: {
    color: '#8e8eab',
    fontWeight: 'bold',
    width: 75,
    fontSize: 12,
  },
  infoValue: {
    color: '#ffffff',
    fontWeight: '600',
    flex: 1,
    fontSize: 13,
  },
  textCard: {
    backgroundColor: '#1f1f33',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#383858',
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00ff97',
    marginBottom: 8,
    flex: 1,
  },
  subText: {
    color: '#a0a0c0',
    fontSize: 13,
    marginTop: 4,
  },
  badgeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginVertical: 4,
  },
  badge: {
    backgroundColor: '#2a2a44',
    color: '#e0e0ff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontSize: 12,
    overflow: 'hidden',
  },
  codeBadge: {
    backgroundColor: '#00ff97',
    color: '#12121e',
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    fontSize: 12,
  },
  detailCard: {
    padding: 16,
    alignItems: 'center',
  },
  detailImage: {
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 3,
    borderColor: '#00ff97',
    marginBottom: 16,
  },
  detailTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00ff97',
    marginBottom: 20,
    textAlign: 'center',
  },
  detailInfoBox: {
    width: '100%',
    backgroundColor: '#1f1f33',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#383858',
  },
});