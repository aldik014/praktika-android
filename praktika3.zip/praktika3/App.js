import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  SafeAreaView,
  StatusBar,
  Switch,
} from 'react-native';

const LIGHT_THEME = {
  mode: 'light',
  background: '#F4F6F8',
  cardBg: '#FFFFFF',
  textPrimary: '#1A1D20',
  textSecondary: '#6C757D',
  primary: '#0D6EFD',
  accent: '#FFC107',
  badgeBg: '#E7F5FF',
  badgeText: '#0D6EFD',
  border: '#E9ECEF',
};

const DARK_THEME = {
  mode: 'dark',
  background: '#121212',
  cardBg: '#1E1E1E',
  textPrimary: '#F8F9FA',
  textSecondary: '#ADB5BD',
  primary: '#3D8BFD',
  accent: '#FFC107',
  badgeBg: '#1C2B3E',
  badgeText: '#6EA8FE',
  border: '#2C2C2C',
};

const AUTO_FACTS = [
  {
    id: '1',
    date: '27 Сен 2026',
    title: '1. Легендарные «четыре глаза» W210',
    description: 'Mercedes-Benz W210, представленный в 1995 году, стал первым автомобилем марки с раздельной овальной передней оптикой, давшей начало новому дизайну.',
    localImage: require('./w210.jpg'), 
    category: 'История',
  },
  {
    id: '2',
    date: '26 Сен 2026',
    title: '2. Проверка давления в шинах',
    description: 'Проверяйте давление в шинах минимум раз в месяц и обязательно перед дальними поездками. Недокачанные шины увеличивают расход топлива на 3-5%.',
    image: 'https://images.unsplash.com/photo-1578844251758-2f71da64c96f?w=800',
    category: 'Совет по уходу',
  },
  {
    id: '3',
    date: '25 Сен 2026',
    title: '3. Идеальная развесовка BMW E46',
    description: 'Инженеры BMW при проектировании шасси E46 добились близкого к идеальному распределению массы по осям 50:50 для безупречной управляемости.',
    localImage: require('./e46.jpg'), 
    category: 'Инженерия',
  },
  {
    id: '4',
    date: '24 Сен 2026',
    title: '4. Замена моторного масла',
    description: 'Рекомендуется менять моторное масло каждые 7 000 – 10 000 км пробега или раз в год, даже если автомобиль эксплуатировался редко.',
    image: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=800',
    category: 'Обслуживание',
  },
  {
    id: '5',
    date: '23 Сен 2026',
    title: '5. Двигатели V6 Lambda в Kia Cadenza',
    description: '3.5-литровый двигатель V6 Lambda II на Kia Cadenza VG развивает около 290 л.с. и отличается высокой надежностью при регулярном ТО.',
    localImage: require('./3.5cadenza.jpg'), 
    category: 'Двигатели',
  },
  {
    id: '6',
    date: '22 Сен 2026',
    title: '6. Кондиционер зимой',
    description: 'Включайте кондиционер минимум на 10 минут раз в месяц зимой, чтобы смазочный материал в хладагенте не застаивался и уплотнители не сохли.',
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?w=800',
    category: 'Совет по уходу',
  },
  {
    id: '7',
    date: '21 Сен 2026',
    title: '7. Происхождение эмблемы Audi',
    description: 'Четыре кольца Audi символизируют объединение четырех автопроизводителей: Audi, DKW, Horch и Wanderer в концерн Auto Union в 1932 году.',
    image: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=800',
    category: 'История',
  },
  {
    id: '8',
    date: '20 Сен 2026',
    title: '8. Обкатка тормозных колодок',
    description: 'После замены тормозных колодок избегайте резких торможений первые 200–300 км, чтобы фрикционный материал равномерно прижгся к дискам.',
    image: 'https://images.unsplash.com/photo-1600793575654-910699b5e4d4?w=800',
    category: 'Безопасность',
  },
  {
    id: '9',
    date: '18 Сен 2026',
    title: '9. Фирменный ключ Porsche слева',
    description: 'Замок зажигания в Porsche традиционно расположен слева от руля. Это наследие гонок в Ле-Мане, где гонщики экономили секунды при старте.',
    image: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800',
    category: 'Факты',
  },
  {
    id: '10',
    date: '18 Сен 2026',
    title: '10. Уход за фарной оптикой',
    description: 'Полировка пластиковых фар и нанесение защитной бронепленки предотвращают их помутнение от ультрафиолета и пескоструя.',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
    category: 'Детейлинг',
  },
  {
    id: '11',
    date: '17 Сен 2026',
    title: '11. Полный привод Quattro',
    description: 'Система Quattro от Audi совершила революцию в ралли в 1980-х годах, доказав превосходство полного привода на любом покрытии.',
    image: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=800',
    category: 'Технологии',
  },
  {
    id: '12',
    date: '16 Сен 2026',
    title: '12. Тормозная жидкость гигроскопична',
    description: 'Тормозная жидкость впитывает влагу из воздуха. Ее необходимо менять каждые 2 года, иначе температура кипения снизится, что опасно.',
    image: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=800',
    category: 'Безопасность',
  },
  {
    id: '13',
    date: '15 Сен 2026',
    title: '13. Ручная сборка моторов Nissan GT-R',
    description: 'Двигатели V6 VR38DETT для Nissan GT-R собираются вручную всего несколькими мастерами высшей квалификации, называемыми «Такуми».',
    localImage: require('./gtr.jpg'), 
    category: 'Инженерия',
  },
  {
    id: '14',
    date: '14 Сен 2026',
    title: '14. Замена салонного фильтра',
    description: 'Забитый салонный фильтр вызывает запотевание стекол и неприятный запах. Меняйте его каждые 15 000 км или перед началом каждого сезона.',
    image: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800',
    category: 'Обслуживание',
  },
  {
    id: '15',
    date: '13 Сен 2026',
    title: '15. Первое поколение Ford Mustang',
    description: 'Ford Mustang 1964 года создала новую категорию автомобилей — Pony Cars. В первый же день было продано более 22 000 экземпляров.',
    image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?w=800',
    category: 'История',
  },
  {
    id: '16',
    date: '12 Сен 2026',
    title: '16. Эффект гидропланирования',
    description: 'При движении по мокрой дороге на высокой скорости между шиной и асфальтом образуется водяной клин. Снижайте скорость в дождь.',
    image: 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=800',
    category: 'Безопасность',
  },
  {
    id: '17',
    date: '11 Сен 2026',
    title: '17. Возвращение легенды Toyota Supra',
    description: 'Поколение Supra A90 было разработано совместно с BMW, поэтому автомобиль получил рядный шестицилиндровый турбомотор B58.',
    localImage: require('./supra.jpg'), 
    category: 'Технологии',
  },
  {
    id: '18',
    date: '10 Сен 2026',
    title: '18. Защита кузова от коррозии',
    description: 'Регулируемая мойка днища в зимний период смывает дорожные реагенты и соли, продлевая жизнь металлу и подвеске.',
    image: 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?w=800',
    category: 'Детейлинг',
  },
  {
    id: '19',
    date: '09 Сен 2026',
    title: '19. Класс Hot-Hatch и Golf GTI',
    description: 'Volkswagen Golf GTI 2018 года доказал, что компактный семейный хэтчбек может быть быстрыми и дарить спортивные эмоции.',
    localImage: require('./golf.jpg'), 
    category: 'История',
  },
  {
    id: '20',
    date: '08 Сен 2026',
    title: '20. Турботаймер и охлаждение турбины',
    description: 'После активной езды на турбированном моторе дайте ему поработать 1–2 минуты на холостых оборотах для охлаждения подшипников турбины.',
    image: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=800',
    category: 'Совет по уходу',
  },
  {
    id: '21',
    date: '07 Сен 2026',
    title: '21. Подвеска SBC на Mercedes W211',
    description: 'Ранние версии W211 оснащались электрогидравлической системой тормозов Sensotronic Brake Control (SBC), требовавшей специализированного ТО.',
    localImage: require('./w211.jpg'), 
    category: 'Технологии',
  },
  {
    id: '22',
    date: '06 Сен 2026',
    title: '22. Состояние аккумулятора',
    description: 'Средний срок службы автомобильного аккумулятора составляет 3–5 лет. Падение напряжения ниже 12.4 В указывает на необходимость зарядки.',
    image: 'https://images.unsplash.com/photo-1563720223185-11003d516935?w=800',
    category: 'Обслуживание',
  },
  {
    id: '23',
    date: '05 Сен 2026',
    title: '23. Двигатель S54 в BMW M3 E46',
    description: 'Атмосферная шестерка S54B32 выдавала 343 л.с. и крутилась до 8000 об/мин, завоевав шесть наград «Международный двигатель года».',
    localImage: require('./e46.jpg'), 
    category: 'Инженерия',
  },
  {
    id: '24',
    date: '04 Сен 2026',
    title: '24. Проверка свечей зажигания',
    description: 'Изношенные свечи зажигания приводят к пропускам воспламенения, повышенному расходу топлива и снижению мощности двигателя.',
    image: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=800',
    category: 'Обслуживание',
  },
  {
    id: '25',
    date: '03 Сен 2026',
    title: '25. Пневмоподвеска AIRMATIC',
    description: 'Система AIRMATIC на авто бизнес-класса регулирует клиренс и жесткость амортизаторов в зависимости от скорости и качества дороги.',
    image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800',
    category: 'Комфорт',
  },
  {
    id: '26',
    date: '02 Сен 2026',
    title: '26. Проверка охлаждающей жидкости',
    description: 'Никогда не открывайте крышку расширительного бачка на горячем двигателе — закипевший антифриз находится под высоким давлением.',
    image: 'https://images.unsplash.com/photo-1578844251758-2f71da64c96f?w=800',
    category: 'Безопасность',
  },
  {
    id: '27',
    date: '01 Сен 2026',
    title: '27. Защитный состав Керамика (Ceramic)',
    description: 'Керамическое покрытие создает гидрофобный слой на лаке, защищая от легких царапин, птичьего помета и химических реагентов.',
    image: 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?w=800',
    category: 'Детейлинг',
  },
  {
    id: '28',
    date: '31 Авг 2026',
    title: '28. Замена ремня ГРМ',
    description: 'Обрыв ремня ГРМ на большинстве моторов приводит к роковому загибу клапанов. Соблюдайте регламент замены каждые 60 000–90 000 км.',
    image: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?w=800',
    category: 'Обслуживание',
  },
  {
    id: '29',
    date: '30 Авг 2026',
    title: '29. Правильная регулировка зеркал',
    description: 'В боковых зеркалах должно быть видно лишь небольшое крыло вашего авто (около 10% площади). Это минимизирует мертвые зоны.',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
    category: 'Совет по уходу',
  },
  {
    id: '30',
    date: '29 Авг 2026',
    title: '30. Тормозные диски из карбон-керамики',
    description: 'Карбон-керамические тормоза выдерживают нагрев свыше 1000 °C без потери эффективности и служат в разы дольше стальных.',
    image: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800',
    category: 'Технологии',
  },
];

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const theme = isDarkMode ? DARK_THEME : LIGHT_THEME;
  const renderItem = ({ item }) => {
    const imageSource = item.localImage ? item.localImage : { uri: item.image };
    return (
      <View style={[styles.card, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
        <Image source={imageSource} style={styles.cardImage} resizeMode="cover" />
        <View style={styles.cardContent}>
          <View style={styles.metaRow}>
            <View style={[styles.badge, { backgroundColor: theme.badgeBg }]}>
              <Text style={[styles.badgeText, { color: theme.badgeText }]}>{item.category}</Text>
            </View>
            <Text style={[styles.dateText, { color: theme.textSecondary }]}>📅 {item.date}</Text>
          </View>
          <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.title}</Text>
          <Text style={[styles.cardDescription, { color: theme.textSecondary }]}>
            {item.description}
          </Text>
        </View>
      </View>
    );
  };
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <View style={[styles.header, { backgroundColor: theme.cardBg, borderBottomColor: theme.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: theme.textPrimary }]}>
            Авто-Факты & Советы
          </Text>
          <Text style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
            30 практических заметок
          </Text>
        </View>
        <View style={styles.themeToggleContainer}>
          <Text style={{ fontSize: 16, marginRight: 4 }}>
            {isDarkMode ? '🌙' : '☀️'}
          </Text>
          <Switch
            value={isDarkMode}
            onValueChange={(value) => setIsDarkMode(value)}
            trackColor={{ false: '#D3D3D3', true: theme.primary }}
            thumbColor={isDarkMode ? theme.accent : '#FFFFFF'}
          />
        </View>
      </View>
      <FlatList
        data={AUTO_FACTS}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listPadding}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  themeToggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  listPadding: {
    padding: 16,
  },
  card: {
    borderRadius: 16,
    marginBottom: 18,
    borderWidth: 1,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 4,
  },
  cardImage: {
    width: '100%',
    height: 180,
  },
  cardContent: {
    padding: 18,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  badge: {
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  dateText: {
    fontSize: 12,
    fontWeight: '500',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    lineHeight: 24,
  },
  cardDescription: {
    fontSize: 14,
    lineHeight: 20,
  },
});