import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  SafeAreaView,
  Alert,
  Switch,
  ActivityIndicator,
  StatusBar,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
const AuthContext = createContext();
const LmsContext = createContext();
const INITIAL_CATEGORIES = [
  { id: '1', name: 'Программирование' },
  { id: '2', name: 'Дизайн' },
  { id: '3', name: 'Маркетинг' },
];
const INITIAL_USERS = [
  {
    id: 'u1',
    email: 'admin@lms.com',
    password: 'admin',
    fullName: 'Алдияр Администратор',
    role: 'Admin',
    isBlocked: false,
  },
  {
    id: 'u2',
    email: 'teacher@lms.com',
    password: 'teacher',
    fullName: 'Азамат Преподаватель',
    role: 'Teacher',
    isBlocked: false,
  },
  {
    id: 'u3',
    email: 'student@lms.com',
    password: 'student',
    fullName: 'Азат Студент',
    role: 'Student',
    isBlocked: false,
  },
];
const INITIAL_COURSES = [
  {
    id: 'c1',
    title: 'Разработка приложений на React Native',
    description: 'Изучите основы создания мобильных кроссплатформенных приложений.',
    category: 'Программирование',
    authorId: 'u2',
    authorName: 'Азамат Преподаватель',
    lessons: [
      {
        id: 'l1',
        title: '1. Введение в React Native',
        type: 'text',
        content: 'React Native позволяет создавать нативные мобильные приложения с использованием JavaScript и React.',
      },
      {
        id: 'l2',
        title: '2. Компоненты и Стили',
        type: 'video',
        content: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      },
      {
        id: 'l3',
        title: '3. Проверка знаний',
        type: 'test',
        question: 'Какой фреймворк используется в курсе?',
        options: ['Flutter', 'React Native', 'Swift'],
        correctAnswer: 1,
      },
    ],
  },
];
const mockHashPassword = (pwd) => `hashed_${pwd}_secret`;
function LmsProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState(INITIAL_USERS);
  const [courses, setCourses] = useState(INITIAL_COURSES);
  const [categories, setCategories] = useState(INITIAL_CATEGORIES);
  const [userProgress, setUserProgress] = useState({});
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    loadData();
  }, []);
  const loadData = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem('@users');
      const storedCourses = await AsyncStorage.getItem('@courses');
      const storedCats = await AsyncStorage.getItem('@categories');
      const storedProgress = await AsyncStorage.getItem('@progress');
      if (storedUsers) setUsers(JSON.parse(storedUsers));
      if (storedCourses) setCourses(JSON.parse(storedCourses));
      if (storedCats) setCategories(JSON.parse(storedCats));
      if (storedProgress) setUserProgress(JSON.parse(storedProgress));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };
  const saveData = async (key, data) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(e);
    }
  };
  const login = (email, password) => {
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return { success: false, message: 'Пользователь не найден' };
    if (user.isBlocked) return { success: false, message: 'Ваш аккаунт заблокирован' };
    if (user.password !== password) return { success: false, message: 'Неверный пароль' };
    setCurrentUser(user);
    return { success: true };
  };
  const register = (fullName, email, password, role) => {
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { success: false, message: 'Email уже зарегистрирован' };
    }
    const newUser = {
      id: Date.now().toString(),
      fullName,
      email,
      password,
      role: role || 'Student',
      isBlocked: false,
    };
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    saveData('@users', updatedUsers);
    setCurrentUser(newUser);
    return { success: true };
  };
  const oauthLogin = (provider) => {
    const mockEmail = `user_${provider.toLowerCase()}@example.com`;
    let user = users.find((u) => u.email === mockEmail);
    if (!user) {
      user = {
        id: Date.now().toString(),
        fullName: `${provider} Пользователь`,
        email: mockEmail,
        password: 'oauth_password',
        role: 'Student',
        isBlocked: false,
      };
      const updated = [...users, user];
      setUsers(updated);
      saveData('@users', updated);
    }
    setCurrentUser(user);
  };
  const logout = () => setCurrentUser(null);
  const updateProfile = (fullName, password) => {
    const updatedUsers = users.map((u) =>
      u.id === currentUser.id ? { ...u, fullName, password: password || u.password } : u
    );
    setUsers(updatedUsers);
    saveData('@users', updatedUsers);
    setCurrentUser({ ...currentUser, fullName, password: password || currentUser.password });
  };
  const addCourse = (courseData) => {
    const newCourse = {
      id: Date.now().toString(),
      authorId: currentUser.id,
      authorName: currentUser.fullName,
      lessons: [],
      ...courseData,
    };
    const updated = [newCourse, ...courses];
    setCourses(updated);
    saveData('@courses', updated);
  };
  const deleteCourse = (courseId) => {
    const updated = courses.filter((c) => c.id !== courseId);
    setCourses(updated);
    saveData('@courses', updated);
  };
  const addLessonToCourse = (courseId, lesson) => {
    const updated = courses.map((c) => {
      if (c.id === courseId) {
        return { ...c, lessons: [...c.lessons, { id: Date.now().toString(), ...lesson }] };
      }
      return c;
    });
    setCourses(updated);
    saveData('@courses', updated);
  };
  const toggleLessonComplete = (courseId, lessonId) => {
    if (!currentUser) return;
    const userId = currentUser.id;
    const userProg = userProgress[userId] || {};
    const courseProg = userProg[courseId] || [];
    let updatedCourseProg;
    if (courseProg.includes(lessonId)) {
      updatedCourseProg = courseProg.filter((id) => id !== lessonId);
    } else {
      updatedCourseProg = [...courseProg, lessonId];
    }
    const updatedProgress = {
      ...userProgress,
      [userId]: {
        ...userProg,
        [courseId]: updatedCourseProg,
      },
    };
    setUserProgress(updatedProgress);
    saveData('@progress', updatedProgress);
  };
  const toggleBlockUser = (userId) => {
    const updated = users.map((u) => (u.id === userId ? { ...u, isBlocked: !u.isBlocked } : u));
    setUsers(updated);
    saveData('@users', updated);
  };
  const updateUserRole = (userId, newRole) => {
    const updated = users.map((u) => (u.id === userId ? { ...u, role: newRole } : u));
    setUsers(updated);
    saveData('@users', updated);
  };
  const addCategory = (name) => {
    const newCat = { id: Date.now().toString(), name };
    const updated = [...categories, newCat];
    setCategories(updated);
    saveData('@categories', updated);
  };
  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f172a' }}>
        <ActivityIndicator size="large" color="#38bdf8" />
      </View>
    );
  }
  return (
    <AuthContext.Provider value={{ currentUser, login, register, oauthLogin, logout, updateProfile }}>
      <LmsContext.Provider
        value={{
          users,
          courses,
          categories,
          userProgress,
          addCourse,
          deleteCourse,
          addLessonToCourse,
          toggleLessonComplete,
          toggleBlockUser,
          updateUserRole,
          addCategory,
        }}
      >
        {children}
      </LmsContext.Provider>
    </AuthContext.Provider>
  );
}
function LoginScreen({ navigation }) {
  const { login, oauthLogin } = useContext(AuthContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert('Ошибка', 'Заполните все поля');
      return;
    }
    const res = login(email, password);
    if (!res.success) Alert.alert('Ошибка авторизации', res.message);
  };
  return (
    <SafeAreaView style={styles.authContainer}>
      <ScrollView contentContainerStyle={{ padding: 24 }}>
        <Text style={styles.authTitle}>Вход в LMS</Text>
        <Text style={styles.authSubtitle}>Система управления обучением</Text>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="admin@lms.com"
          placeholderTextColor="#64748b"
          autoCapitalize="none"
        />
        <Text style={styles.label}>Пароль</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor="#64748b"
          secureTextEntry
        />
        <TouchableOpacity style={styles.primaryBtn} onPress={handleLogin}>
          <Text style={styles.btnText}>Войти</Text>
        </TouchableOpacity>
        <View style={{ marginVertical: 20, alignItems: 'center' }}>
          <Text style={{ color: '#94a3b8' }}>или войдите через социальные сети</Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <TouchableOpacity
            style={[styles.oauthBtn, { backgroundColor: '#ea4335' }]}
            onPress={() => oauthLogin('Google')}
          >
            <Text style={styles.btnText}>Google</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.oauthBtn, { backgroundColor: '#24292e' }]}
            onPress={() => oauthLogin('GitHub')}
          >
            <Text style={styles.btnText}>GitHub</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={{ marginTop: 24, alignItems: 'center' }}
          onPress={() => navigation.navigate('Register')}
        >
          <Text style={{ color: '#38bdf8' }}>Нет аккаунта? Зарегистрироваться</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
function RegisterScreen({ navigation }) {
  const { register } = useContext(AuthContext);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Student');
  const handleRegister = () => {
    if (!fullName || !email || !password) {
      Alert.alert('Ошибка', 'Заполните обязательные поля');
      return;
    }
    const res = register(fullName, email, password, role);
    if (!res.success) Alert.alert('Ошибка', res.message);
  };
  return (
    <SafeAreaView style={styles.authContainer}>
      <ScrollView contentContainerStyle={{ padding: 24 }}>
        <Text style={styles.authTitle}>Регистрация</Text>
        <Text style={styles.label}>ФИО</Text>
        <TextInput
          style={styles.input}
          value={fullName}
          onChangeText={setFullName}
          placeholder="Иванов Иван"
          placeholderTextColor="#64748b"
        />
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="user@example.com"
          placeholderTextColor="#64748b"
          autoCapitalize="none"
        />
        <Text style={styles.label}>Пароль</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor="#64748b"
          secureTextEntry
        />
        <Text style={styles.label}>Выберите роль</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
          {['Student', 'Teacher'].map((r) => (
            <TouchableOpacity
              key={r}
              style={[styles.roleChip, role === r && styles.roleChipActive]}
              onPress={() => setRole(r)}
            >
              <Text style={[styles.roleChipText, role === r && { color: '#0f172a' }]}>
                {r === 'Student' ? 'Студент' : 'Преподаватель'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={styles.primaryBtn} onPress={handleRegister}>
          <Text style={styles.btnText}>Создать аккаунт</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{ marginTop: 20, alignItems: 'center' }}
          onPress={() => navigation.goBack()}
        >
          <Text style={{ color: '#38bdf8' }}>Уже есть аккаунт? Войти</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
function CoursesListScreen({ navigation }) {
  const { courses, categories, userProgress } = useContext(LmsContext);
  const { currentUser } = useContext(AuthContext);
  const [selectedCat, setSelectedCat] = useState(null);
  const [search, setSearch] = useState('');
  const filteredCourses = courses.filter((c) => {
    const matchesCat = selectedCat ? c.category === selectedCat : true;
    const matchesSearch = c.title.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });
  const getCourseProgress = (course) => {
    if (!currentUser || !course.lessons.length) return 0;
    const completedIds = userProgress[currentUser.id]?.[course.id] || [];
    return Math.round((completedIds.length / course.lessons.length) * 100);
  };
  return (
    <SafeAreaView style={styles.container}>
      <View style={{ padding: 16 }}>
        <TextInput
          style={styles.input}
          placeholder="Поиск курсов..."
          placeholderTextColor="#64748b"
          value={search}
          onChangeText={setSearch}
        />
      </View>
      <View style={{ paddingLeft: 16, marginBottom: 12 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity
            style={[styles.catChip, selectedCat === null && styles.catChipActive]}
            onPress={() => setSelectedCat(null)}
          >
            <Text style={[styles.catChipText, selectedCat === null && { color: '#0f172a' }]}>
              Все
            </Text>
          </TouchableOpacity>
          {categories.map((cat) => (
            <TouchableOpacity
              key={cat.id}
              style={[styles.catChip, selectedCat === cat.name && styles.catChipActive]}
              onPress={() => setSelectedCat(cat.name)}
            >
              <Text style={[styles.catChipText, selectedCat === cat.name && { color: '#0f172a' }]}>
                {cat.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <FlatList
        data={filteredCourses}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={<Text style={styles.emptyText}>Курсы не найдены</Text>}
        renderItem={({ item }) => {
          const progress = getCourseProgress(item);
          return (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate('CourseDetail', { courseId: item.id })}
            >
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={styles.cardCategory}>{item.category}</Text>
                <Text style={{ color: '#94a3b8', fontSize: 12 }}>Автор: {item.authorName}</Text>
              </View>
              <Text style={styles.cardTitle}>{item.title}</Text>
              <Text style={styles.cardDesc} numberOfLines={2}>
                {item.description}
              </Text>
              <View style={{ marginTop: 12 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ color: '#94a3b8', fontSize: 12 }}>Прогресс</Text>
                  <Text style={{ color: '#38bdf8', fontSize: 12, fontWeight: 'bold' }}>
                    {progress}%
                  </Text>
                </View>
                <View style={styles.progressBarBg}>
                  <View style={[styles.progressBarFill, { width: `${progress}%` }]} />
                </View>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </SafeAreaView>
  );
}
function CourseDetailScreen({ route, navigation }) {
  const { courseId } = route.params;
  const { courses, userProgress, toggleLessonComplete, deleteCourse } = useContext(LmsContext);
  const { currentUser } = useContext(AuthContext);
  const course = courses.find((c) => c.id === courseId);
  if (!course) return null;
  const completedLessons = userProgress[currentUser?.id]?.[course.id] || [];
  const isAuthorOrAdmin =
    currentUser?.role === 'Admin' || (currentUser?.role === 'Teacher' && course.authorId === currentUser?.id);
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.cardCategory}>{course.category}</Text>
        <Text style={styles.detailTitle}>{course.title}</Text>
        <Text style={{ color: '#94a3b8', marginBottom: 12 }}>Преподаватель: {course.authorName}</Text>
        <Text style={styles.detailDesc}>{course.description}</Text>
        {isAuthorOrAdmin && (
          <View style={{ flexDirection: 'row', gap: 8, marginVertical: 16 }}>
            <TouchableOpacity
              style={[styles.primaryBtn, { flex: 1 }]}
              onPress={() => navigation.navigate('AddLesson', { courseId: course.id })}
            >
              <Text style={styles.btnText}>+ Урок</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.deleteBtn, { flex: 1 }]}
              onPress={() => {
                deleteCourse(course.id);
                navigation.goBack();
              }}
            >
              <Text style={styles.btnText}>Удалить курс</Text>
            </TouchableOpacity>
          </View>
        )}
        <Text style={styles.sectionHeader}>Уроки курса ({course.lessons.length})</Text>
        {course.lessons.map((lesson, idx) => {
          const isDone = completedLessons.includes(lesson.id);
          return (
            <TouchableOpacity
              key={lesson.id}
              style={styles.lessonCard}
              onPress={() => navigation.navigate('LessonView', { courseId: course.id, lessonId: lesson.id })}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.lessonTitle}>{lesson.title}</Text>
                <Text style={{ color: '#64748b', fontSize: 12 }}>
                  Тип: {lesson.type === 'text' ? 'Лекция' : lesson.type === 'video' ? 'Видео' : 'Тест'}
                </Text>
              </View>
              <TouchableOpacity
                style={[styles.checkBtn, isDone && styles.checkBtnActive]}
                onPress={() => toggleLessonComplete(course.id, lesson.id)}
              >
                <Text style={{ color: isDone ? '#0f172a' : '#94a3b8', fontWeight: 'bold' }}>
                  {isDone ? '✓' : 'O'}
                </Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}
function LessonViewScreen({ route }) {
  const { courseId, lessonId } = route.params;
  const { courses, toggleLessonComplete, userProgress } = useContext(LmsContext);
  const { currentUser } = useContext(AuthContext);
  const [selectedOption, setSelectedOption] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const course = courses.find((c) => c.id === courseId);
  const lesson = course?.lessons.find((l) => l.id === lessonId);
  if (!lesson) return null;
  const isCompleted = userProgress[currentUser?.id]?.[courseId]?.includes(lessonId);
  const handleTestSubmit = () => {
    if (selectedOption === null) return;
    if (selectedOption === lesson.correctAnswer) {
      setTestResult('Верно! Отличная работа.');
      if (!isCompleted) toggleLessonComplete(courseId, lessonId);
    } else {
      setTestResult('Неверно. Попробуйте еще раз.');
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.detailTitle}>{lesson.title}</Text>
        {lesson.type === 'text' && (
          <View style={styles.contentBox}>
            <Text style={{ color: '#e2e8f0', fontSize: 16, lineHeight: 24 }}>{lesson.content}</Text>
          </View>
        )}
        {lesson.type === 'video' && (
          <View style={styles.contentBox}>
            <Text style={{ color: '#38bdf8', marginBottom: 8 }}>[Видеоматериал]</Text>
            <Text style={{ color: '#94a3b8' }}>Ссылка на поток: {lesson.content}</Text>
          </View>
        )}
        {lesson.type === 'test' && (
          <View style={styles.contentBox}>
            <Text style={{ color: '#f8fafc', fontSize: 18, marginBottom: 12 }}>{lesson.question}</Text>
            {lesson.options?.map((opt, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.optionBtn, selectedOption === idx && styles.optionBtnSelected]}
                onPress={() => setSelectedOption(idx)}
              >
                <Text style={{ color: '#ffffff' }}>{opt}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={[styles.primaryBtn, { marginTop: 12 }]} onPress={handleTestSubmit}>
              <Text style={styles.btnText}>Проверить ответ</Text>
            </TouchableOpacity>
            {testResult && (
              <Text style={{ color: testResult.includes('Верно') ? '#4ade80' : '#f87171', marginTop: 12 }}>
                {testResult}
              </Text>
            )}
          </View>
        )}
        <TouchableOpacity
          style={[styles.primaryBtn, { marginTop: 24, backgroundColor: isCompleted ? '#22c55e' : '#0284c7' }]}
          onPress={() => toggleLessonComplete(courseId, lessonId)}
        >
          <Text style={styles.btnText}>
            {isCompleted ? 'Урок пройден (Сбросить)' : 'Отметить как пройденный'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
function CreateCourseScreen({ navigation }) {
  const { addCourse, categories } = useContext(LmsContext);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState(categories[0]?.name || 'Программирование');
  const handleCreate = () => {
    if (!title || !description) {
      Alert.alert('Ошибка', 'Заполните название и описание');
      return;
    }
    addCourse({ title, description, category });
    navigation.goBack();
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.authTitle}>Новый курс</Text>
        <Text style={styles.label}>Название курса</Text>
        <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="Введите название" placeholderTextColor="#64748b" />
        <Text style={styles.label}>Категория</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
          {categories.map((cat) => (
            <TouchableOpacity
              key={cat.id}
              style={[styles.catChip, category === cat.name && styles.catChipActive]}
              onPress={() => setCategory(cat.name)}
            >
              <Text style={[styles.catChipText, category === cat.name && { color: '#0f172a' }]}>
                {cat.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <Text style={styles.label}>Описание</Text>
        <TextInput
          style={[styles.input, { height: 100 }]}
          value={description}
          onChangeText={setDescription}
          multiline
          placeholder="Подробное описание..."
          placeholderTextColor="#64748b"
        />
        <TouchableOpacity style={styles.primaryBtn} onPress={handleCreate}>
          <Text style={styles.btnText}>Опубликовать курс</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
function AddLessonScreen({ route, navigation }) {
  const { courseId } = route.params;
  const { addLessonToCourse } = useContext(LmsContext);
  const [title, setTitle] = useState('');
  const [type, setType] = useState('text'); // text, test
  const [content, setContent] = useState('');
  const [question, setQuestion] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const handleAdd = () => {
    if (!title) return Alert.alert('Ошибка', 'Введите название урока');
    if (type === 'text') {
      addLessonToCourse(courseId, { title, type, content });
    } else {
      addLessonToCourse(courseId, {
        title,
        type,
        question,
        options: [opt1, opt2],
        correctAnswer: 0,
      });
    }
    navigation.goBack();
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.authTitle}>Добавить урок</Text>
        <Text style={styles.label}>Название урока</Text>
        <TextInput style={styles.input} value={title} onChangeText={setTitle} placeholder="Например: Урок 1" placeholderTextColor="#64748b" />
        <Text style={styles.label}>Тип урока</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
          {['text', 'test'].map((t) => (
            <TouchableOpacity
              key={t}
              style={[styles.roleChip, type === t && styles.roleChipActive]}
              onPress={() => setType(t)}
            >
              <Text style={[styles.roleChipText, type === t && { color: '#0f172a' }]}>
                {t === 'text' ? 'Лекция (Текст)' : 'Тест'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        {type === 'text' ? (
          <>
            <Text style={styles.label}>Содержимое лекции</Text>
            <TextInput
              style={[styles.input, { height: 120 }]}
              value={content}
              onChangeText={setContent}
              multiline
              placeholder="Текст лекции..."
              placeholderTextColor="#64748b"
            />
          </>
        ) : (
          <>
            <Text style={styles.label}>Вопрос</Text>
            <TextInput style={styles.input} value={question} onChangeText={setQuestion} placeholder="Текст вопроса" placeholderTextColor="#64748b" />
            <Text style={styles.label}>Вариант 1 (Правильный)</Text>
            <TextInput style={styles.input} value={opt1} onChangeText={setOpt1} placeholder="Ответ 1" placeholderTextColor="#64748b" />
            <Text style={styles.label}>Вариант 2</Text>
            <TextInput style={styles.input} value={opt2} onChangeText={setOpt2} placeholder="Ответ 2" placeholderTextColor="#64748b" />
          </>
        )}

        <TouchableOpacity style={styles.primaryBtn} onPress={handleAdd}>
          <Text style={styles.btnText}>Сохранить урок</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
function AdminPanelScreen() {
  const { users, courses, categories, toggleBlockUser, updateUserRole, addCategory } = useContext(LmsContext);
  const [newCatName, setNewCatName] = useState('');
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.authTitle}>Панель Администратора</Text>
        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>{users.length}</Text>
            <Text style={styles.statLabel}>Пользователей</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>{courses.length}</Text>
            <Text style={styles.statLabel}>Курсов</Text>
          </View>
        </View>
        <Text style={styles.sectionHeader}>Управление Секциями / Категориями</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
          <TextInput
            style={[styles.input, { flex: 1, marginBottom: 0 }]}
            value={newCatName}
            onChangeText={setNewCatName}
            placeholder="Новая категория"
            placeholderTextColor="#64748b"
          />
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => {
              if (newCatName) {
                addCategory(newCatName);
                setNewCatName('');
              }
            }}
          >
            <Text style={styles.btnText}>+</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.sectionHeader}>Пользователи системы</Text>
        {users.map((u) => (
          <View key={u.id} style={styles.userCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.userName}>{u.fullName}</Text>
              <Text style={{ color: '#64748b', fontSize: 12 }}>{u.email}</Text>
              <Text style={{ color: '#38bdf8', fontSize: 12, marginTop: 4 }}>Роль: {u.role}</Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 6 }}>
              <TouchableOpacity
                style={[styles.smallBtn, { backgroundColor: u.isBlocked ? '#22c55e' : '#ef4444' }]}
                onPress={() => toggleBlockUser(u.id)}
              >
                <Text style={styles.btnText}>{u.isBlocked ? 'Разблок.' : 'Блок'}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.smallBtn, { backgroundColor: '#334155' }]}
                onPress={() => {
                  const nextRole = u.role === 'Student' ? 'Teacher' : u.role === 'Teacher' ? 'Admin' : 'Student';
                  updateUserRole(u.id, nextRole);
                }}
              >
                <Text style={{ color: '#f8fafc', fontSize: 10 }}>Сменить роль</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}
function ProfileScreen() {
  const { currentUser, logout, updateProfile } = useContext(AuthContext);
  const [fullName, setFullName] = useState(currentUser?.fullName || '');
  const [password, setPassword] = useState('');
  const handleUpdate = () => {
    updateProfile(fullName, password);
    Alert.alert('Успех', 'Данные профиля обновлены');
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={styles.authTitle}>Мой профиль</Text>
        <View style={styles.profileBadge}>
          <Text style={{ color: '#38bdf8', fontWeight: 'bold', fontSize: 16 }}>{currentUser?.role}</Text>
        </View>
        <Text style={styles.label}>Email</Text>
        <TextInput style={[styles.input, { opacity: 0.6 }]} value={currentUser?.email} editable={false} />
        <Text style={styles.label}>ФИО</Text>
        <TextInput style={styles.input} value={fullName} onChangeText={setFullName} />
        <Text style={styles.label}>Новый пароль (опционально)</Text>
        <TextInput
          style={styles.input}
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor="#64748b"
          secureTextEntry
        />
        <TouchableOpacity style={styles.primaryBtn} onPress={handleUpdate}>
          <Text style={styles.btnText}>Сохранить изменения</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.deleteBtn, { marginTop: 24 }]} onPress={logout}>
          <Text style={styles.btnText}>Выйти из аккаунта</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
function MainTabs() {
  const { currentUser } = useContext(AuthContext);
  const isAdmin = currentUser?.role === 'Admin';
  const isTeacher = currentUser?.role === 'Teacher' || isAdmin;
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#0f172a' },
        headerTintColor: '#f8fafc',
        tabBarStyle: { backgroundColor: '#0f172a', borderTopColor: '#1e293b' },
        tabBarActiveTintColor: '#38bdf8',
        tabBarInactiveTintColor: '#64748b',
      }}
    >
      <Tab.Screen name="Courses" component={CoursesListScreen} options={{ title: 'Курсы' }} />
      {isTeacher && (
        <Tab.Screen name="CreateCourse" component={CreateCourseScreen} options={{ title: 'Создать курс' }} />
      )}
      {isAdmin && (
        <Tab.Screen name="Admin" component={AdminPanelScreen} options={{ title: 'Админ-панель' }} />
      )}
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: 'Профиль' }} />
    </Tab.Navigator>
  );
}
function NavigationRoot() {
  const { currentUser } = useContext(AuthContext);
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#0f172a' },
          headerTintColor: '#f8fafc',
        }}
      >
        {!currentUser ? (
          <>
            <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />
          </>
        ) : (
          <>
            <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
            <Stack.Screen name="CourseDetail" component={CourseDetailScreen} options={{ title: 'О курсе' }} />
            <Stack.Screen name="LessonView" component={LessonViewScreen} options={{ title: 'Урок' }} />
            <Stack.Screen name="AddLesson" component={AddLessonScreen} options={{ title: 'Добавить урок' }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default function App() {
  return (
    <LmsProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0f172a" />
      <NavigationRoot />
    </LmsProvider>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  authContainer: {
    flex: 1,
    backgroundColor: '#0f172a',
    justifyContent: 'center',
  },
  authTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#f8fafc',
    marginBottom: 6,
  },
  authSubtitle: {
    fontSize: 14,
    color: '#94a3b8',
    marginBottom: 24,
  },
  label: {
    color: '#94a3b8',
    marginBottom: 6,
    fontSize: 13,
  },
  input: {
    backgroundColor: '#1e293b',
    color: '#f8fafc',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#334155',
  },
  primaryBtn: {
    backgroundColor: '#0284c7',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  deleteBtn: {
    backgroundColor: '#ef4444',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  btnText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  oauthBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  roleChip: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#1e293b',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  roleChipActive: {
    backgroundColor: '#38bdf8',
  },
  roleChipText: {
    color: '#94a3b8',
    fontWeight: 'bold',
  },
  catChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: '#1e293b',
    marginRight: 8,
  },
  catChipActive: {
    backgroundColor: '#38bdf8',
  },
  catChipText: {
    color: '#94a3b8',
    fontSize: 13,
  },
  card: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#334155',
  },
  cardCategory: {
    color: '#38bdf8',
    fontSize: 12,
    fontWeight: 'bold',
  },
  cardTitle: {
    color: '#f8fafc',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 4,
  },
  cardDesc: {
    color: '#94a3b8',
    fontSize: 13,
    marginTop: 6,
  },
  emptyText: {
    color: '#64748b',
    textAlign: 'center',
    marginTop: 40,
  },
  progressBarBg: {
    height: 6,
    backgroundColor: '#334155',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#38bdf8',
  },
  detailTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f8fafc',
    marginBottom: 8,
  },
  detailDesc: {
    color: '#cbd5e1',
    fontSize: 15,
    lineHeight: 22,
  },
  sectionHeader: {
    color: '#f8fafc',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 12,
  },
  lessonCard: {
    backgroundColor: '#1e293b',
    padding: 14,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  lessonTitle: {
    color: '#f8fafc',
    fontWeight: '600',
  },
  checkBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#334155',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkBtnActive: {
    backgroundColor: '#38bdf8',
  },
  contentBox: {
    backgroundColor: '#1e293b',
    padding: 16,
    borderRadius: 8,
    marginVertical: 12,
  },
  optionBtn: {
    backgroundColor: '#334155',
    padding: 12,
    borderRadius: 6,
    marginTop: 8,
  },
  optionBtnSelected: {
    backgroundColor: '#0284c7',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statBox: {
    flex: 1,
    backgroundColor: '#1e293b',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  statNum: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#38bdf8',
  },
  statLabel: {
    color: '#94a3b8',
    fontSize: 12,
  },
  userCard: {
    backgroundColor: '#1e293b',
    padding: 12,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    color: '#f8fafc',
    fontWeight: 'bold',
  },
  smallBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
  },
  profileBadge: {
    backgroundColor: '#1e293b',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
  },
});