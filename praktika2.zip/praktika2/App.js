import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Modal,
  SafeAreaView,
  StatusBar,
} from 'react-native';

const CAR_COLLECTION = [
  {
    id: 1,
    title: 'Mercedes-Benz E-Class (W210)',
    author: 'Mercedes-Benz',
    year: 1995,
    localImage: require('./w210.jpg'),
    description: 'Легендарный седан бизнес-класса, известный своим узнаваемым «глазастым» дизайном оптики и высоким уровнем комфорта.',
  },
  {
    id: 2,
    title: 'Mercedes-Benz E-Class (W211)',
    author: 'Mercedes-Benz',
    year: 2002,
    localImage: require('./w211.jpg'),
    description: 'Преемник W210 с более элегантным аэродинамичным кузовом, инновационной подвеской и передовой электроникой.',
  },
  {
    id: 3,
    title: 'BMW 3 Series (E46)',
    author: 'BMW AG',
    year: 1998,
    localImage: require('./e46.jpg'),
    description: 'Четвёртое поколение 3-й серии, получившее статус культового автомобиля благодаря идеальной управляемости и дизайну.',
  },
  {
    id: 4,
    title: 'Kia Cadenza (VG)',
    author: 'Kia Motors',
    year: 2013,
    localImage: require('./cadenza.jpg'),
    description: 'Полноразмерный бизнес-седан, сочетающий мощный двигатель V6 3.5L на 290 лошадинных сил, богатое оснащение и современный дизайн.',
  },
  {
    id: 5,
    title: 'Audi A6 (C6)',
    author: 'Audi AG',
    year: 2004,
    localImage: require('./a6.jpg'),
    description: 'Бизнес-седан с фирменной системой полного привода Quattro и узнаваемой решёткой радиатора Singleframe.',
  },
  {
    id: 6,
    title: 'Porsche 911 Carrera',
    author: 'Porsche',
    year: 2019,
    imageUrl: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800',
    description: 'Эталон спортивного автомобиля с заднемоторной компоновкой и непревзойдённой динамикой.',
  },
  {
    id: 7,
    title: 'Nissan GT-R (R35)',
    author: 'Nissan',
    year: 2007,
    localImage: require('./gtr.jpg'),
    description: 'Легендарный спорткар по прозвищу «Годзилла», оснащённый интеллектуальным полным приводом и двигателем V6 Twin-Turbo.',
  },
  {
    id: 8,
    title: 'Ford Mustang GT',
    author: 'Ford',
    year: 2018,
    localImage: require('./mustang.jpg'),
    description: 'Американский масл-кар с агрессивным характером и мощным атмосферным двигателем V8.',
  },
  {
    id: 9,
    title: 'Toyota Supra (A90)',
    author: 'Toyota',
    year: 2019,
    localImage: require('./supra.jpg'),
    description: 'Возвращение легендарного спорткара, разработанного в сотрудничестве с инженерами BMW.',
  },
  {
    id: 10,
    title: 'Volkswagen Golf GTI',
    author: 'Volkswagen',
    year: 2017,
    localImage: require('./golf.jpg'),
    description: 'Классический «горячий» хэтчбек, сочетающий практичность на каждый день и спортивный азарт.',
  },
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const currentItem = CAR_COLLECTION[currentIndex];
  useEffect(() => {
    console.log(`Открыт элемент #${currentIndex + 1}: ${currentItem.title}`);
  }, [currentIndex]);
  const handleNext = () => {
    if (currentIndex < CAR_COLLECTION.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };
  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };
  const isFirstItem = currentIndex === 0;
  const isLastItem = currentIndex === CAR_COLLECTION.length - 1;
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.container}>
        <Text style={styles.headerTitle}>Автомобильный каталог</Text>
        <Text style={styles.counterText}>
          {currentIndex + 1} из {CAR_COLLECTION.length}
        </Text>
        <TouchableOpacity
          activeOpacity={0.9}
          onLongPress={() => setIsModalVisible(true)}
          style={styles.cardContainer}
        >
          <Image
            source={currentItem.localImage ? currentItem.localImage : { uri: currentItem.imageUrl }}
            style={styles.image}
            resizeMode="cover"
          />
          <View style={styles.cardContent}>
            <Text style={styles.itemTitle}>{currentItem.title}</Text>
            <Text style={styles.itemAuthor}>Производитель: {currentItem.author}</Text>
            <Text style={styles.itemYear}>Год выпуска: {currentItem.year}</Text>
            
            <View style={styles.hintBadge}>
              <Text style={styles.hintBadgeText}>💡 Удерживайте для подробностей</Text>
            </View>
          </View>
        </TouchableOpacity>
        <View style={styles.navigationRow}>
          <TouchableOpacity
            style={[styles.navButton, isFirstItem && styles.disabledButton]}
            onPress={handlePrev}
            disabled={isFirstItem}
          >
            <Text style={[styles.navButtonText, isFirstItem && styles.disabledButtonText]}>
              ◀ Назад
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.navButton, isLastItem && styles.disabledButton]}
            onPress={handleNext}
            disabled={isLastItem}
          >
            <Text style={[styles.navButtonText, isLastItem && styles.disabledButtonText]}>
              Вперёд ▶
            </Text>
          </TouchableOpacity>
        </View>
        <Modal
          visible={isModalVisible}
          transparent={true}
          animationType="fade"
          onRequestClose={() => setIsModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>{currentItem.title}</Text>
              <Text style={styles.modalSubtitle}>
                {currentItem.author} ({currentItem.year})
              </Text>
              <View style={styles.modalDivider} />
              <Text style={styles.modalDescriptionTitle}>Подробное описание:</Text>
              <Text style={styles.modalDescription}>{currentItem.description}</Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setIsModalVisible(false)}
              >
                <Text style={styles.closeButtonText}>Закрыть</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f4f6f8',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1a1a1a',
    marginTop: 10,
  },
  counterText: {
    fontSize: 14,
    color: '#6c757d',
    marginBottom: 10,
  },
  cardContainer: {
    width: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 10,
    elevation: 6,
  },
  image: {
    width: '100%',
    height: 220,
  },
  cardContent: {
    padding: 20,
  },
  itemTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212529',
    marginBottom: 6,
  },
  itemAuthor: {
    fontSize: 15,
    color: '#495057',
    marginBottom: 2,
  },
  itemYear: {
    fontSize: 14,
    color: '#6c757d',
    marginBottom: 12,
  },
  hintBadge: {
    backgroundColor: '#e7f5ff',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  hintBadgeText: {
    fontSize: 12,
    color: '#1c7ed6',
    fontWeight: '600',
  },
  navigationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginVertical: 15,
  },
  navButton: {
    flex: 0.48,
    backgroundColor: '#0d6efd',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#ced4da',
  },
  navButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  disabledButtonText: {
    color: '#6c757d',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    width: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212529',
    marginBottom: 4,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#6c757d',
  },
  modalDivider: {
    height: 1,
    backgroundColor: '#e9ecef',
    marginVertical: 14,
  },
  modalDescriptionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    marginBottom: 6,
  },
  modalDescription: {
    fontSize: 15,
    color: '#343a40',
    lineHeight: 22,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: '#212529',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '600',
  },
});